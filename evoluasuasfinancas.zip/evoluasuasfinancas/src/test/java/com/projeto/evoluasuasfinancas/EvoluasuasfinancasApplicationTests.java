package com.projeto.evoluasuasfinancas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvoluasuasfinancasApplicationTests {

	@Test
	void contextLoads() {
	}

}
